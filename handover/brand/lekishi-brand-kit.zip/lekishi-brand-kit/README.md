# Lekishi brand kit

The Lekishi logo is the **Meridian dial**: a globe tilted 23.4° (the Earth's axial tilt) inside the arc of a time window. The window ends at a gold playhead. The **wordmark** is LEKISHI in Cinzel capitals, then a hairline, then 歴史 (*rekishi*, "history").

Every file here is generated from `src/lib/ui/brand.ts` in the repository (merged in PR #24), so these files match the site. Text is outlined, so you don't need any fonts installed to use them.

## What to use where

Every file comes as a vector in `svg/` and as bitmaps in `png/`, in the same subfolders (`lockup/`, `mark/`, `wordmark/`, `app-icon/`, `social/`). PNG names end in their pixel width.

| You need | Use |
| --- | --- |
| The logo with the name | `lockup/lekishi-lockup-bilingual-*` |
| The logo where space is tight (under about 200 px wide) | `lockup/lekishi-lockup-caps-*` |
| The symbol on its own (avatars, stamps, watermarks) | `mark/lekishi-mark-*` |
| The name on its own | `wordmark/lekishi-wordmark-*` |
| An app or profile icon | `app-icon/lekishi-app-icon-square-*` (iOS and Android round the corners themselves) or `-rounded-*` |
| A browser favicon | `app-icon/lekishi-favicon.svg`, `lekishi-favicon.ico`, `lekishi-favicon-16/32/48.png` |
| A link preview (Open Graph, X/Twitter) | `social/lekishi-social-card-1200x630.png` |

Prefer the SVGs. Use the PNGs only where SVG isn't accepted. All PNGs except the app icons and the social card have transparent backgrounds.

## Colourways

Every logo comes in four versions. Pick by the background:

| Suffix | Background | Ink | Playhead |
| --- | --- | --- | --- |
| `on-dark` | Dark, ideally lacquer `#121a20` | Ink `#f3ead7` | Gold `#d2a94f` |
| `on-light` | Light, ideally paper `#f1e9d8` or white | Lacquer `#121a20` | Dark gold `#9a7425` |
| `mono-black` | Light, one-colour printing, embossing | Black | Black |
| `mono-white` | Photos, coloured grounds | White | White |

`on-dark` is the primary version, because the site is a dark atlas. The dark gold `#9a7425` exists only for light grounds, where the site gold is too faint. It is not a site token.

## Rules

- **One gold.** The playhead is the only gold element. Don't add gold anywhere else in the logo, and don't recolour the playhead except in the mono versions.
- **Keep the tilt.** Don't rotate, straighten, stretch or mirror the mark. The 23.4° lean is the Earth's.
- **Use the drawing cut for the size.** For the mark at 32 px or smaller, use `mark/lekishi-mark-32px-*`. At 16 px, use `lekishi-mark-16px-*`. Never scale the large mark down to those sizes.
- **Minimum sizes.** Use the bilingual lockup at 200 px wide or more. Between 120 and 200 px, use the caps lockup. Below 120 px, use the mark alone.
- **Clear space.** Keep empty space around the logo of at least half the mark's height on every side.
- **No effects.** No shadows, glows, outlines or gradients, and don't place the logo over busy imagery without a solid ground.

## Type

- **Cinzel SemiBold:** LEKISHI and Latin display titles.
- **Noto Serif JP:** 歴史, historical names and narrative.
- **Noto Sans JP:** interface text.

All three typefaces are under the SIL Open Font License 1.1, so they're free to use anywhere. The logo files contain outlines only, not the fonts.

## Changing the logo

Edit `src/lib/ui/brand.ts`, then run `pnpm brand` to rewrite the site's own logo files. Ask Claude in the Lekishi project to regenerate this kit afterwards. The construction and the decisions behind it are in RFD 5, under "Mark and wordmark".
